<div class="bandeorange"></div>   
                    <div class="container">   
                <footer>
                    <div class="foot">
                        <div id="copylogo">
                            <p>© <?php echo date('Y'); ?> </p>
                            <img class="share" src="images/logof.png" alt="logo">
                        </div>
                        <p>Mentions légales</p>
                        <a href="https://www.youtube.com/watch?v=fDMTYUGa1_4">
                            <img class="hieroglyphe" src="images/hieroglyphe.png" alt="hieroglyphe">
                        </a>
                    </div>    
                </footer>
            </div>  
           
        </body>
    </html>